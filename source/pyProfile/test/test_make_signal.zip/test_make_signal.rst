.. code:: ipython3

    # Da Profile_class_test
    
    %reset
    %load_ext autoreload
    %autoreload 2


.. parsed-literal::

    Once deleted, variables cannot be recovered. Proceed (y/[n])? y
    The autoreload extension is already loaded. To reload it, use:
      %reload_ext autoreload
    

.. code:: ipython3

    %qtconsole

.. code:: ipython3

    
    
     %matplotlib inline

.. code:: ipython3

    import matplotlib.pyplot as plt
    import numpy as np
    import os
    
    from dataIO.span import span
    from dataIO.fn_add_subfix import fn_add_subfix
    
    from IPython.display import display
    from plotting.backends import maximize

.. code:: ipython3

    pwd




.. parsed-literal::

    'C:\\Users\\kovor\\Documents\\python\\pyXTel\\pyxsurf\\pyProfile\\test'



.. code:: ipython3

    np




.. parsed-literal::

    <module 'numpy' from 'C:\\Users\\kovor\\Anaconda3\\lib\\site-packages\\numpy\\__init__.py'>



Appendix: make_signal
---------------------

.. code:: ipython3

    from pyProfile.profile_class import Profile
    from pyProfile.profile import make_signal

.. code:: ipython3

    make_signal?

.. code:: ipython3

    # use helper function to create x and y:
    x,y = make_signal(amp=10.,L=30.,N=21,nwaves=2.8,ystartend=(0,0),noise=0)
    
    # plot them with usual matplotlib commands:
    plt.plot(x,y)




.. parsed-literal::

    [<matplotlib.lines.Line2D at 0x184361817f0>]




.. image:: output_9_1.png


.. code:: ipython3

    %matplotlib

Creo un segnale (reale). Ne creo una copia sottocampionata per test,
ovviamente sono tutti valori reali.

.. code:: ipython3

    L=1
    N=11
    
    plt.clf()
    x,y=make_signal(1,L=1,N=101,nwaves=3)
    plt.plot(x,y,label='harmonic signal with 0 phase')
    x,y=make_signal(1,L=1,N=N,nwaves=3)
    plt.plot(x,y,'o',label='downsampled curve')
    x,y=make_signal(1,L=1,N=101,nwaves=3,phase=np.pi/4)
    plt.plot(x,y,label='phase pi/4')
    plt.grid(1)
    plt.legend(loc=0)




.. parsed-literal::

    <matplotlib.legend.Legend at 0x2a55959feb8>




.. image:: output_12_1.png


Quindi ora posso creare segnali complessi arbitrari usando due segnali
con stessa frequenza e fase diversa su reale e immaginario.

Questo ovviamente significa che posso usare una serie di ca N/2
armoniche per descrivere interamente il segnale, a patto di fornire
anche la fase.

Option ``minus_one``
~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    
    plt.clf()
    A=make_signal(1,L=1,N=N,nwaves=nwaves)
    plt.plot(*A)
    print(A[0].shape)
    print(A[1].shape)



.. parsed-literal::

    <Figure size 432x288 with 0 Axes>


.. code:: ipython3

    # redo plot adding "minux_one option"
    plt.clf()
    plt.plot(*A)
    
    plt.plot(*(make_signal(1,L=1,N=N,nwaves=nwaves,minus_one=True)),'o')
    
    plt.grid(1)
    plt.xlim([0.97,1.01])
    plt.ylim([-0.2,0.1])
    plt.show()



.. parsed-literal::

    <Figure size 432x288 with 0 Axes>


.. code:: ipython3

    # makes a 2d surface from matlab data 
    # fit 2D
    # estrai profili dritti o in diagonale
    
